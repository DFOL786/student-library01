"""Free local student authentication for Student Library.

Uses only Python's standard library + Streamlit. Student records are stored in a
SQLite database at data/student_library.db. Passwords are never stored in plain
text; PBKDF2-HMAC-SHA256 with a per-user random salt is used instead.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import re
import secrets
import sqlite3
from datetime import datetime, timezone
from typing import Dict, Optional, Tuple

import streamlit as st

DB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
DB_PATH = os.path.join(DB_DIR, "student_library.db")
PBKDF2_ITERATIONS = 260_000
GMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@gmail\.com$")


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _connect() -> sqlite3.Connection:
    os.makedirs(DB_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_auth_db() -> None:
    """Create the free SQLite database and students table if needed."""
    with _connect() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                gmail TEXT NOT NULL UNIQUE COLLATE NOCASE,
                address TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                password_salt TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                last_login_at TEXT
            )
            """
        )
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_students_gmail ON students(gmail COLLATE NOCASE)")


def normalize_gmail(value: str) -> str:
    return (value or "").strip().lower()


def validate_signup(name: str, gmail: str, address: str, password: str, confirm_password: str) -> Tuple[bool, str]:
    name = (name or "").strip()
    gmail = normalize_gmail(gmail)
    address = (address or "").strip()

    if len(name) < 2:
        return False, "Enter your full name."
    if len(name) > 100:
        return False, "Name is too long."
    if not GMAIL_RE.fullmatch(gmail):
        return False, "Enter a valid Gmail address ending in @gmail.com."
    if len(address) < 3:
        return False, "Enter your address."
    if len(address) > 300:
        return False, "Address is too long."
    if len(password or "") < 8:
        return False, "Password must be at least 8 characters."
    if password != confirm_password:
        return False, "Passwords do not match."
    return True, ""


def _hash_password(password: str, salt: Optional[bytes] = None) -> Tuple[str, str]:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        PBKDF2_ITERATIONS,
    )
    return digest.hex(), salt.hex()


def _verify_password(password: str, stored_hash: str, stored_salt: str) -> bool:
    try:
        salt = bytes.fromhex(stored_salt)
        candidate_hash, _ = _hash_password(password, salt)
        return hmac.compare_digest(candidate_hash, stored_hash)
    except Exception:
        return False


def create_student(name: str, gmail: str, address: str, password: str, confirm_password: str) -> Tuple[bool, str]:
    init_auth_db()
    ok, message = validate_signup(name, gmail, address, password, confirm_password)
    if not ok:
        return False, message

    gmail = normalize_gmail(gmail)
    name = name.strip()
    address = address.strip()
    password_hash, password_salt = _hash_password(password)
    now = _utc_now()

    try:
        with _connect() as conn:
            conn.execute(
                """
                INSERT INTO students
                (name, gmail, address, password_hash, password_salt, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (name, gmail, address, password_hash, password_salt, now, now),
            )
        return True, "Account created successfully. You can now sign in."
    except sqlite3.IntegrityError:
        return False, "An account with this Gmail already exists."
    except sqlite3.Error:
        return False, "Could not create the account. Please try again."


def authenticate_student(gmail: str, password: str) -> Tuple[bool, Optional[Dict], str]:
    init_auth_db()
    gmail = normalize_gmail(gmail)
    if not gmail or not password:
        return False, None, "Enter Gmail and password."

    with _connect() as conn:
        row = conn.execute("SELECT * FROM students WHERE gmail = ? COLLATE NOCASE", (gmail,)).fetchone()
        if row is None or not _verify_password(password, row["password_hash"], row["password_salt"]):
            return False, None, "Invalid Gmail or password."
        now = _utc_now()
        conn.execute("UPDATE students SET last_login_at = ? WHERE id = ?", (now, row["id"]))

    user = {
        "id": row["id"],
        "name": row["name"],
        "gmail": row["gmail"],
        "address": row["address"],
        "created_at": row["created_at"],
        "last_login_at": now,
    }
    return True, user, "Signed in successfully."


def get_student(student_id: int) -> Optional[Dict]:
    init_auth_db()
    with _connect() as conn:
        row = conn.execute(
            "SELECT id, name, gmail, address, created_at, updated_at, last_login_at FROM students WHERE id = ?",
            (student_id,),
        ).fetchone()
    return dict(row) if row else None


def update_student_profile(student_id: int, name: str, address: str) -> Tuple[bool, str, Optional[Dict]]:
    name = (name or "").strip()
    address = (address or "").strip()
    if len(name) < 2 or len(name) > 100:
        return False, "Enter a valid full name.", None
    if len(address) < 3 or len(address) > 300:
        return False, "Enter a valid address.", None

    try:
        with _connect() as conn:
            cursor = conn.execute(
                "UPDATE students SET name = ?, address = ?, updated_at = ? WHERE id = ?",
                (name, address, _utc_now(), student_id),
            )
            if cursor.rowcount != 1:
                return False, "Student account was not found.", None
        return True, "Profile updated successfully.", get_student(student_id)
    except sqlite3.Error:
        return False, "Could not update the profile.", None


def change_student_password(student_id: int, current_password: str, new_password: str, confirm_password: str) -> Tuple[bool, str]:
    if len(new_password or "") < 8:
        return False, "New password must be at least 8 characters."
    if new_password != confirm_password:
        return False, "New passwords do not match."

    with _connect() as conn:
        row = conn.execute(
            "SELECT password_hash, password_salt FROM students WHERE id = ?",
            (student_id,),
        ).fetchone()
        if row is None:
            return False, "Student account was not found."
        if not _verify_password(current_password, row["password_hash"], row["password_salt"]):
            return False, "Current password is incorrect."
        password_hash, password_salt = _hash_password(new_password)
        conn.execute(
            "UPDATE students SET password_hash = ?, password_salt = ?, updated_at = ? WHERE id = ?",
            (password_hash, password_salt, _utc_now(), student_id),
        )
    return True, "Password changed successfully."


def render_auth_gate(app_name: str = "Student Library") -> None:
    """Show Login / Sign Up until a student is authenticated."""
    init_auth_db()
    if "auth_user" not in st.session_state:
        st.session_state.auth_user = None
    if st.session_state.auth_user:
        return

    st.markdown(f'<div class="main-title">📚 {app_name}</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="subtitle">Student Login • Sign Up • Your private AI study workspace</div>',
        unsafe_allow_html=True,
    )

    left, center, right = st.columns([1, 1.25, 1])
    with center:
        st.info("Create a free student account to use the library. The built-in account database uses SQLite and has no subscription fee.")
        login_tab, signup_tab = st.tabs(["🔐 Login", "📝 Sign Up"])

        with login_tab:
            with st.form("student_login_form", clear_on_submit=False):
                gmail = st.text_input("Gmail", placeholder="student@gmail.com")
                password = st.text_input("Password", type="password")
                submitted = st.form_submit_button("Login", type="primary", use_container_width=True)
                if submitted:
                    ok, user, message = authenticate_student(gmail, password)
                    if ok and user:
                        st.session_state.auth_user = user
                        st.success(message)
                        st.rerun()
                    else:
                        st.error(message)

        with signup_tab:
            with st.form("student_signup_form", clear_on_submit=False):
                name = st.text_input("Name", placeholder="Your full name")
                gmail = st.text_input("Gmail", placeholder="student@gmail.com", key="signup_gmail")
                address = st.text_area("Address", placeholder="Your address", height=90)
                password = st.text_input("Password", type="password", key="signup_password")
                confirm = st.text_input("Confirm password", type="password")
                submitted = st.form_submit_button("Create free account", type="primary", use_container_width=True)
                if submitted:
                    ok, message = create_student(name, gmail, address, password, confirm)
                    if ok:
                        st.success(message)
                    else:
                        st.error(message)

        st.caption("Password security: passwords are stored as salted PBKDF2 hashes, never as plain text.")

    st.stop()
